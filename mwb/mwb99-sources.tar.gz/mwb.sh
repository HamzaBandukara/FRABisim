#!/bin/sh
sml @SMLload=mwb $*
